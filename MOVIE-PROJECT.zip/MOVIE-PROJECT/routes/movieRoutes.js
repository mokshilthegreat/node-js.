const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movieController");

// Use only "/add", NOT "/api/movies/add"
router.post("/add", movieController.addMovie); 

module.exports = router;