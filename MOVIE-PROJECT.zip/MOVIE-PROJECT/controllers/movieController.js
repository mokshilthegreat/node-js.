const Movie = require('../models/movie');

exports.getMovies = async (req, res) => {
    try {
               let query = { ...req.query };
      
        Object.keys(query).forEach(key => {
            query[key] = new RegExp(req.query[key], 'i');
        });

        const movies = await Movie.find(query);
        res.status(200).json(movies);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


exports.addMovie = async (req, res) => {
    try {
        const newMovie = await Movie.create(req.body);
        res.status(201).json(newMovie);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};


exports.updateMovie = async (req, res) => {
    try {
        const updated = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.status(200).json(updated);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};


exports.deleteMovie = async (req, res) => {
    try {
        await Movie.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: "Movie Deleted" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};