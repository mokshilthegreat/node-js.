const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
    movieName: { type: String, required: true },
    movieTime: { type: String, required: true },
    hero: { type: String, required: true },
    heroine: { type: String, required: true },
    type: { type: String, required: true }, // Genre
    director: { type: String, required: true },
    language: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Movie', movieSchema);