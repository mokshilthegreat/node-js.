// 1. Import necessary modules
const express = require("express");
const connectDB = require("./config/db"); // Ensure this path matches your folder structure

// 2. Initialize the app
const app = express();

// 3. Connect to the Database
connectDB();

// 4. Middleware (CRITICAL: This must be BEFORE the routes)
// This allows your server to read JSON data sent from Postman
app.use(express.json());

// 5. Link your Routes
// This means every route in movieRoutes will start with /api/movies
const movieRoutes = require("./routes/movieRoutes");
app.use("/api/movies", movieRoutes);

// 6. Basic Route for testing in the browser (Optional)
app.get("/", (req, res) => {
  res.send("Movie API is running...");
});

// 7. Define the Port
const PORT = 5000;

// 8. Start the Server
app.listen(PORT, () => {
  console.log(`\n=================================`);
  console.log(`Server is running on port ${PORT}`);
  console.log(`URL: http://localhost:${PORT}`);
  console.log(`=================================\n`);
});